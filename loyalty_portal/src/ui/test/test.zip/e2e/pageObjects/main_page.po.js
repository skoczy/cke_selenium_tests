var MainPage = function () {

	var generalDataLink = element(by.linkText("General data"));
	var siteServicesLink = element(by.linkText("Site services"));
	var fuelsLink = element(by.linkText("Fuels"));
	var sitePersonsLink = element(by.linkText("Site persons"));
	var exportAllDataLink = element(by.linkText("Export all data"));
	var printAllDataLink = element(by.linkText("Print all data"));
    var searchInput = element(by.model("search.searchValue"));
	var signOutLink = element(by.linkText("Sign out"));

	this.generalDataClick = function () {
        generalDataLink.click();
	}
	
	this.siteServicesClick = function () {
        siteServicesLink.click();
	}

	this.fuelsLinkClick = function () {
        fuelsLink.click();
	}

	this.sitePersonsLinkClick = function () {
        sitePersonsLink.click();
	}	
	
	this.exportAllDataLinkClick = function () {
        exportAllDataLink.click();
	}		
	
	this.printAllDataLinkClick = function () {
        printAllDataLink.click();
	}	

    this.getSearch = function () {
        return searchInput.getAttribute('value');
    }

    this.setSearch = function (val) {
        searchInput.clear().sendKeys(val);
    }

    this.clickSearch = function() {
        element(by.name("mainCtrl.searchForm")).submit();
    }
	
    this.signOutLinkClick = function() {
        signOutLink.click();
    }	
	
};
module.exports = MainPage;