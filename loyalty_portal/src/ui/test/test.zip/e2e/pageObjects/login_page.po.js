var LoginPage = function () {
	
    var username = element(by.name("username"));
    var password = element(by.name("password"));
    var signInBtn = element(by.name("signin"));
    
	this.getLoginPage = function () {
        browser.get('https://sitemaster-prep.sfrlabs.com/#/login');
    };
    
	this.setUsername = function (name) {
        username.sendKeys(name);
    };
    
	this.setPassword = function (_password) {
        password.sendKeys(_password);
    };
    
	this.enterUsername = function () {
        this.setUsername('tomsko@statoilfuelretail.com');
    };
	
	this.enterPassword = function () {
        this.setPassword('34erDF34');
    };
    
	this.signIn = function () {
        signInBtn.click();
    }
};

module.exports = LoginPage;