var SitePersonsPage = function () {
	
    this.addNewPerson = element(by.linkText("Add new person"));
	
	var sitePersonsForm = element(by.name("personsForm"));
	
	this.sitePersonsFormSubmit = function () {
        sitePersonsForm.submit();
	}
	
	this.saveBtn = element(by.id('personsForm')).element(by.css('input[type="submit"]'));
	
	var removePersonLink = function (n) {
    //return element.all(by.css("form[name='servicesForm'] td.remove")).get(n - 1);
	return element.all(by.linkText("Remove")).get(n - 1);
    };
	
	this.removePerson= function (n) {
        return removePersonLink(n).click();
    };
	
	/*
	
    var nameField = function (n) {
        return element.all(by.model("person.name")).get(n - 1);
    };
    var phoneCCField = function (n) {
        return element.all(by.model("person.phonecc")).get(n - 1);
    };
    var phoneField = function (n) {
        return element.all(by.model("person.phone")).get(n - 1);
    };
    var emailField = function (n) {
        return element.all(by.model("person.email")).get(n - 1);
    };

    var removeLink = function (n) {
        return element.all(by.css("form[name='personsForm'] td.remove")).get(n - 1);
    };

    this.go = function () {
        element(by.linkText("Site persons")).click();
    };

    this.get = function (siteId) {
        browser.get('/#/site/' + siteId + '/persons');
    };

    this.addNewPerson = function () {
        addNewPersons.click();
    };

    this.getLastPersonIndex = function () {
        return element.all(by.model("person.name")).count().then(function (n) {
            return n;
        });
    };

    this.getPersonRole = function (n) {
        return element(by.css("table.site-persons tbody tr:nth-child(" + n + ") select option:checked")).getText();
    };

    this.setPersonRole = function (n, label) {
        element(by.cssContainingText("table.site-persons tbody tr:nth-child(" + n + ") select option", label)).click()
    };

    this.getPersonName = function (n) {
        return nameField(n).getAttribute('value');
    };

    this.setPersonName = function (n, name) {
        return nameField(n).clear().sendKeys(name);
    };

    this.getPersonPhoneCC = function (n) {
        return phoneCCField(n).getAttribute('value');
    };

    this.setPersonPhoneCC = function (n, cc) {
        return phoneCCField(n).clear().sendKeys(cc);
    };

    this.getPersonPhone = function (n) {
        return phoneField(n).getAttribute('value');
    };

    this.setPersonPhone = function (n, phone) {
        return phoneField(n).clear().sendKeys(phone);
    };

    this.getPersonEmail = function (n) {
        return emailField(n).getAttribute('value');
    };

    this.setPersonEmail = function (n, email) {
        return emailField(n).clear().sendKeys(email);
    };

    this.save = function () {
        saveBtn.click();
    };

    this.removePerson = function (n) {
        return removeLink(n).click();
    };
	
	*/
};
module.exports = SitePersonsPage;