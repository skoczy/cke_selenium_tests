var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPagePO = require('./pageObjects/login_page.po.js');
var MainPagePO = require('./pageObjects/main_page.po.js');
var GeneralDataPO = require('./pageObjects/general_data.po.js');

describe('log in to app -->', function() {
  var login = new LoginPagePO();
		
  it('should login to app...', function() {
	
	browser.driver.manage().window().maximize();
	//browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	//browser.sleep(timeoutSlowest);
    
	login.enterUsername();
	//browser.sleep(timeoutSlowest);
	
	login.enterPassword();
	//browser.sleep(timeoutSlowest);
	
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
  });
});


describe('search specific site -->', function() {
  var mainpage = new MainPagePO();

  it('should display results of this site', function() {
	
	mainpage.setSearch('70220');
	browser.sleep(timeoutSlowest);
    
	mainpage.clickSearch();
	browser.sleep(timeoutSlowest);
	
	browser.waitForAngular();
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');
	
	});
});



describe('unckeck 247 field -->', function() {
  var generaldata = new GeneralDataPO();

  it('should enable opening hours', function() {
	
	// ---> check if 247 checkbox isSelected() - if it is, doubleclick on it to set 247
	element(by.model("site.openingInfo.alwaysOpen")).isSelected().then(function(result) {
		
    if ( result ) {
		
    browser.sleep(timeoutSlowest);
	
	generaldata.open247Click();
	browser.sleep(timeoutSlowest);
	
	generaldata.open247Click();
	browser.sleep(timeoutSlowest);
	
	generaldata.openingHoursSubmit();
	
	browser.sleep(timeoutSlowest);
	
    } else {

		
    browser.sleep(timeoutSlowest);
	
	generaldata.open247Click();
	browser.sleep(timeoutSlowest);
	
	generaldata.openingHoursSubmit();
	
	browser.sleep(timeoutSlowest);
	
    }
});
	
	
	});
});
