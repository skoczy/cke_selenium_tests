var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPagePO = require('./pageObjects/login_page.po.js');
var MainPagePO = require('./pageObjects/main_page.po.js');
var GeneralDataPO = require('./pageObjects/general_data.po.js');

describe('log in to app -->', function() {
  var login = new LoginPagePO();
		
  it('should login to app...', function() {
	
	browser.driver.manage().window().maximize();
	//browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	//browser.sleep(timeoutSlowest);
    
	login.enterUsername();
	//browser.sleep(timeoutSlowest);
	
	login.enterPassword();
	//browser.sleep(timeoutSlowest);
	
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
  });
});


describe('search specific site -->', function() {
  var mainpage = new MainPagePO();

  it('should display results of this site', function() {
	
	mainpage.setSearch('70220');
	browser.sleep(timeoutSlowest);
    
	mainpage.clickSearch();
	browser.sleep(timeoutSlowest);
	
	browser.waitForAngular();
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');
	
	});
});



describe('set temporary closed -->', function() {
  var generaldata = new GeneralDataPO();

  it('should set range of dates', function() {
	
	generaldata.tempCloseFrom.sendKeys("2016-03-20");
	browser.sleep(timeoutSlower);
	generaldata.tempCloseTo.sendKeys("2017-03-20");
	browser.sleep(timeoutSlower);
	generaldata.clearTempDatesBtn.click();
	browser.sleep(timeoutSlower);	
	generaldata.tempCloseFrom.sendKeys("2017-01-15");
	browser.sleep(timeoutSlower);
	generaldata.tempCloseTo.sendKeys("2018-01-15");
	browser.sleep(timeoutSlow);
	generaldata.clearTempDatesBtn.click();
	browser.sleep(timeoutSlow);
	generaldata.tempCloseFrom.sendKeys("2017-01-15");
	browser.sleep(timeoutSlow);
	generaldata.tempCloseTo.sendKeys("2018-01-15");
	browser.sleep(timeoutSlow);

	});
});
