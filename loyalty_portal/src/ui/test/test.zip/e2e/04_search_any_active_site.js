var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPage = require('./pageObjects/login_page.po.js');
var MainPage = require('./pageObjects/main_page.po.js');

describe('log in to app', function() {
  var login = new LoginPage();
		
  it('should login to app', function() {

	
	browser.driver.manage().window().maximize();
	//browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	browser.sleep(timeoutSlowest);
    
	login.enterUsername();
	browser.sleep(timeoutSlowest);
	
	login.enterPassword();
	browser.sleep(timeoutSlowest);
	
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
  });


});

describe('search specific site', function() {
  var mainpage = new MainPage();

  it('should display results of this site', function() {
	
	mainpage.setSearch('70220');
	browser.sleep(timeoutSlowest);
    
	mainpage.clickSearch();
	browser.sleep(timeoutSlowest);
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');

	mainpage.siteServicesClick();
	browser.sleep(timeoutSlowest);
	
	mainpage.fuelsLinkClick();
	browser.sleep(timeoutSlowest);
	
	mainpage.sitePersonsLinkClick();
	browser.sleep(timeoutSlowest);
	
	mainpage.exportAllDataLinkClick();
	browser.sleep(timeoutSlowest);
	
	mainpage.printAllDataLinkClick();
	browser.sleep(timeoutSlowest);
	
    //expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');
  });


});