var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPagePO = require('./pageObjects/login_page.po.js');
var MainPagePO = require('./pageObjects/main_page.po.js');

describe('log in to app', function() {
  var login = new LoginPagePO();
		
  it('should login to app', function() {

	
	browser.driver.manage().window().maximize();
	browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	browser.sleep(timeoutSlowest);
    
	login.enterUsername();
	browser.sleep(timeoutSlowest);
	
	login.enterPassword();
	browser.sleep(timeoutSlowest);
	
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
	
	browser.sleep(timeoutSlowest);
	
  });

});

describe('log out from app', function() {
  var mainpage = new MainPagePO();
		
  it('should go to login screen again', function() {
	
	mainpage.signOutLinkClick();
	browser.sleep(timeoutSlowest);
    
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/login');
	
	browser.sleep(timeoutSlowest);
	
  });

});
