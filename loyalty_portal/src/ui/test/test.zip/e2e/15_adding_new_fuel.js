var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPagePO = require('./pageObjects/login_page.po.js');
var MainPagePO = require('./pageObjects/main_page.po.js');
var FuelsPO = require('./pageObjects/fuels.po.js');

describe('log in to app -->', function() {
  var login = new LoginPagePO();
		
  it('should login to app...', function() {
	
	browser.driver.manage().window().maximize();
	//browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	//browser.sleep(timeoutSlowest);
    
	login.enterUsername();
	//browser.sleep(timeoutSlowest);
	
	login.enterPassword();
	//browser.sleep(timeoutSlowest);
	
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
  });
});


describe('add specific site -->', function() {
  var mainpage = new MainPagePO();

  it('should display results of this site', function() {
	
	mainpage.setSearch('70220');
	browser.sleep(timeoutSlowest);
    
	mainpage.clickSearch();
	browser.waitForAngular()
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');
	
	mainpage.fuelsLinkClick();
	browser.waitForAngular();
	expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220/fuels');
	browser.sleep(timeoutSlowest);
	
	});
});

describe('add new fuel -->', function() {
  var fuels = new FuelsPO();

  it('should actually add fuel for site', function() {
	
	browser.sleep(timeoutSlowest);
	fuels.addNewFuel.click();
	browser.sleep(timeoutSlowest);
	browser.sleep(timeoutSlowest);
	fuels.addNewFuel.click();
	browser.sleep(timeoutSlowest);
	fuels.fuelsFormSubmit();
	browser.waitForAngular();
	browser.sleep(timeoutSlowest);
	fuels.removeFuel(3);
	browser.sleep(timeoutSlowest);
	fuels.removeFuel(2);
	browser.sleep(timeoutSlowest);
	fuels.fuelsFormSubmit();
	browser.waitForAngular();
	browser.sleep(timeoutSlowest);
	
	});
});

