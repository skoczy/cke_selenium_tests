var timeoutFast = 300;
var timeoutSlow = 500;
var timeoutSlower = 1000;
var timeoutSlowest = 1500;

var LoginPagePO = require('./pageObjects/login_page.po.js');
var MainPagePO = require('./pageObjects/main_page.po.js');
var SiteServicesPO = require('./pageObjects/site_services.po.js');

describe('log in to app -->', function() {
  var login = new LoginPagePO();
		
  it('should login to app...', function() {
	
	browser.driver.manage().window().maximize();
	//browser.driver.switchTo().activeElement();	
		
	login.getLoginPage();
	browser.sleep(timeoutSlowest);
	    
	login.enterUsername();
	browser.sleep(timeoutSlowest);
		
	login.enterPassword();
	browser.sleep(timeoutSlowest);
		
	login.signIn();
    browser.waitForAngular();
	
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/');
  });
});


describe('search specific site -->', function() {
  var mainpage = new MainPagePO();

  it('should display results of this site', function() {
	
	mainpage.setSearch('70220');
	browser.sleep(timeoutSlowest);
    
	mainpage.clickSearch();
	browser.waitForAngular()
    expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220');
	
	mainpage.siteServicesClick();
	browser.waitForAngular();
	expect(browser.getCurrentUrl()).toEqual('https://sitemaster-prep.sfrlabs.com/#/site/70220/services');
	browser.sleep(timeoutSlowest);
	
	});
});

describe('add new person -->', function() {
  var siteservices = new SiteServicesPO();

  it('should actually add new person for site', function() {
	
	browser.sleep(timeoutSlowest);
	siteservices.addNewPerson.click();
	browser.sleep(timeoutSlowest);
	browser.sleep(timeoutSlowest);
	siteservices.addNewPerson.click();
	browser.sleep(timeoutSlowest);
	siteservices.sitePersonsFormSubmit();
	browser.waitForAngular();
	browser.sleep(timeoutSlowest);
	siteservices.removePerson(3);
	browser.sleep(timeoutSlowest);
	siteservices.removePerson(3);
	browser.sleep(timeoutSlowest);
	siteservices.sitePersonsFormSubmit();
	browser.waitForAngular();
	browser.sleep(timeoutSlowest);
	
	});
});

